function y = pemphasis(x, p)

% pemphasis     emphasizes the high frequency components of the signal.

arguments
    x;
    p {mustBeFloat(p)} = 0.97;
end
y = filter([1., -p], 1, x);
