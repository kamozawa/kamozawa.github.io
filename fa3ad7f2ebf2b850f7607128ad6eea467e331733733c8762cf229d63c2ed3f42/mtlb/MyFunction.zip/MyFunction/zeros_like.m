function y = zeros_like(x)
% zeros_like    Return an array of zeros with the same shape and type as a given array.
array_size = size(x);
y = zeros(array_size);