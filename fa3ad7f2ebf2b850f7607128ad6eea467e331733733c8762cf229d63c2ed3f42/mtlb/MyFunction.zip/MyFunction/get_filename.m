function files = get_filename(extension, path, absolute)

% get_filename      returns a list containing filename which has the input extension.

arguments
    extension {mustBeText(extension)}
    path {mustBeText(path)} = pwd;
    absolute {mustBeNumericOrLogical(absolute)} = true;
end

switch nargin
    case 2
        search_dir = strcat(path, '/*.', extension);
    
    case 1
        current_directory = pwd;
        search_dir = strcat(current_directory,  '/*.', extension);

    otherwise
        msgbox('Invalid Arguments', 'Error', 'error');
end

field = dir(search_dir);
files = strings(numel(field), 1);

if absolute == true
    for idx = 1:numel(field)
        files(idx) = strcat(field(idx).folder, '\', field(idx).name);
    end

else
    for idx = 1:numel(field)
        files(idx) = strcat(field(idx).name);
    end
end
