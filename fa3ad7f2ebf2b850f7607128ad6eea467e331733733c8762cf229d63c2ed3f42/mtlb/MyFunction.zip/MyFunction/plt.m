function f = plt(x, y, x_label, y_label, linecolor, linewidth)

% plt gives a simple plot(figure) for pptx and paper.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function gives a simple plot(figure) for pptx and paper.
% This code was written by Kamozawa.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
arguments
    x double
    y double
    x_label {mustBeText(x_label)} = "Time [s]"
    y_label {mustBeText(y_label)} = "Amplitude [mV]"
    linecolor {mustBeText(linecolor)} = 'k'
    linewidth {mustBeFloat(linewidth)} = 1.
end

f = figure("Name", "Matplotlib-ish Plot");
f.Units = 'points';
f.Position = [356 219 420 158];

plot(x, y, linecolor, 'LineWidth', linewidth)
ax = gca;
set(ax, 'XMinorTick', 'on', 'YMinorTick', 'on')
xlabel(x_label)
ylabel(y_label)

ax.FontSize = 12.5;
ax.FontName = "Times New Roman";
ax.LineWidth = 1.;

ax.Units = "normalized";
ax.OuterPosition = [0.0044 0.135 1 1.0514];
ax.InnerPosition = [0.1344 0.1912 0.775 0.8];

pbaspect([3.5 1.2 1])

end