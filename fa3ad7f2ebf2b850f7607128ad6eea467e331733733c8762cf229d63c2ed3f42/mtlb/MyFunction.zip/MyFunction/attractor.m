% Compute attractor reconstruction from time-series signal array
function [xout, yout, zout, v, w] = attractor(x, period, fs, display, newfig, Xautolim, Yautolim)
    
arguments
    x {mustBeVector(x)} 
    period {mustBeFloat(period)} 
    fs {mustBeInteger(fs)} 
    display {mustBeNumericOrLogical} = true ;
    newfig {mustBeNumericOrLogical} = true;
    Xautolim {mustBeNumericOrLogical} = true;
    Yautolim {mustBeNumericOrLogical} = true;
end

x = normalize(x, 'range');
tau = floor(period/3 * fs);

xout = x(2*tau+1 : numel(x))';
yout = x(tau+1 : numel(x)-tau)';
zout = x(1 : numel(x)-2*tau)';

v = (xout+yout-2*zout)/sqrt(6);
w = (xout-yout)/sqrt(2);

if display == true
%     close all
    
    if newfig == true
    f = figure();
    f.Position = [65.8 219.4 982.2 542.6];
   
    end

    tiledlayout(2, 2, 'TileSpacing','Compact','Padding','Compact');

    timeax = linspace(0, numel(x)/fs, numel(x));
    ax_plot1d = nexttile(1, [1 2]);
    plot(timeax, x, 'LineWidth', 1.1)
    if Xautolim == true
        xlim([0 period])
    end
    if Yautolim == true
        ylim([min(xout)-0.025 max(xout)+0.025])
    end
    ax_plot1d.FontSize = 11;
    % ax_plot1d.FontName = 'Times New Roman';
    ax_plot1d.XMinorTick = 'on';
    ax_plot1d.YMinorTick = 'on';
    ax_plot1d.LineWidth = 0.9;
    
    xlabel('Time [s]', 'Interpreter', 'latex', 'FontSize', 12)
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12)
    
    ax3d = nexttile;
    plot3(xout, yout, zout)
    grid on
    title('Constant delay time is $\tau =T/3$, where $T$ is period', 'Interpreter', 'latex', 'FontSize', 12)
    xlabel('$x(t)$', 'Interpreter', 'latex', 'FontSize', 12)
    ylabel('$x(t-\tau)$', 'Interpreter', 'latex', 'FontSize', 12)
    zlabel('$x(t-2\tau)$', 'Interpreter', 'latex', 'FontSize', 12)

    xlim([0 1])
    ylim([0 1])
    zlim([0 1])

    ax3d.View = [-2.226423462237835e+02 30.807058823529438];
    ax3d.FontSize = 10.5;
    ax3d.XMinorTick = "on";
    ax3d.YMinorTick = "on";
    ax3d.ZMinorTick = "on";
    ax3d.LineWidth = 0.92;
    
    ax_ar = nexttile;
    grid off
    plot(v, w, 'LineWidth', 1)
    title('Attractor Reconstruction', 'FontSize', 12, 'Interpreter', 'latex')
    xlabel('$v$', 'Interpreter', 'latex', 'FontSize', 14)
    ylabel('$w$', 'Interpreter', 'latex', 'FontSize', 14)
    xlim([-1 1])
    ylim([-1 1])
    % ax_ar.FontSize = 10;
    ax_ar.XMinorTick = "on";
    ax_ar.YMinorTick = "on";
    ax_ar.LineWidth = 0.92;

end

end
