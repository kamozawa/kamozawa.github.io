function voltage = pulse(display, fs, interval, gen_interval, amplitude, rise_time, fall_time, pulse_width)
% pulse     generates a square wave.
arguments
    display {mustBeNumericOrLogical} = true;
    fs (1, 1) {mustBeInteger(fs), mustBePositive(fs), mustBeNonzero(fs)} = 5*1e6;
    interval (1, 1) {mustBePositive(interval), mustBeNonzero(interval)} = 20*1e-6;
    gen_interval (1, 1) {mustBeInteger(gen_interval), mustBePositive(gen_interval), mustBeNonzero(gen_interval)} = 10;
    amplitude (1, 1) = 2.;
    
    rise_time (1, 1) = 0.03 * interval;
    fall_time (1, 1) = 0.07 * interval;
    pulse_width (1, 1) {mustBePositive(pulse_width), mustBeNonzero(pulse_width)} = 0.65 * interval;
    
end

%fs = 1e6;  % サンプリング周波数

%T = 20*1e-6;  % 周期
T = interval;

n_interval = gen_interval;  % 何周期つくる？

time = 1/fs : 1/fs : T ;  % 時間軸

amp = amplitude;  % 振幅
% tr = 0.03 * T;  % 立ち上がり時間
% tf = 0.07 * T;  % 立ち下がり時間
tr = rise_time;
tf = fall_time;

% p_width = 0.65 * T;  % パルス幅
p_width = pulse_width;

% 区間どこまで（インデックス）
area1 = floor(tr * fs);
area2 = floor((tr + p_width - (tr + tf)/2) * fs);
area3 = floor((p_width + (tr + tf)/2) * fs);

% それぞれの時間軸
time1 = 1 : area1;
time2 = area1 + 1 : area2;
time3 = area2 + 1 : area3;
time4 = area3 + 1 : numel(time);

% それぞれの区間での振幅
v1 = amp/tr * time(time1);
v2 = amp + 0 * time(time2);
v3 = -amp/tf * time(time3) + amp/tf*((tr + tf)/2+p_width);
v4 = 0 * time(time4);

% 4つを合体 
v = horzcat(v1, v2, v3, v4);

% 10周期分つなげる
voltage = zeros(1, n_interval * numel(v));
for idx = 0 : n_interval - 1
    voltage(numel(v) * idx + 1 : numel(v) * (idx + 1)) = v;
end

% 波形を確認
if display == true
    figure(1)
    ax = gca;
    
    time = (0 : 1/fs : gen_interval * T - 1/fs);
    plot(time * 1e6, voltage, 'k', 'LineWidth', 1)
    xlabel('Time [\mus]')
    ylabel('Amplitude [V]')
    ylim([min(voltage)-0.02 max(voltage)+0.05])
    
    ax.FontSize = 12;
    ax.FontName = 'Times New Roman';
end

% nfft = 2^15;
% 
% dft = abs(fft(voltage, nfft)).^2/nfft;
% dft = 20 * log10(dft);
% faxis = linspace(0, fs/2, numel(dft));
% 
% figure(2)
% semilogx(faxis, dft)
% ylim([-100 0])
% xlim([1e3 fs/2])
% 
% xlabel('Frequency [Hz]')
% ylabel('Power')

