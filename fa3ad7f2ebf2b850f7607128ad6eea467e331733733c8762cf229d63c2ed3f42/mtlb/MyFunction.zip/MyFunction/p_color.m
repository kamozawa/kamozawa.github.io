function f = p_color(X, Y, Z, x_label, y_label, c_label, cmap, alpha, norm, method)

% pcolor    displays an image plot for pptx and paper.

arguments
    X {mustBeVector(X)}
    Y {mustBeVector(Y)}
    Z ;
    x_label {mustBeText} = "Time [s]";
    y_label {mustBeText} = "Frequency [Hz]";
    c_label {mustBeText} = "Magnitude [dB]";
    cmap = "viridis";
    alpha {mustBeFloat(alpha)} = 1.;
    norm {mustBeNumericOrLogical} = false;
    method {mustBeText} = "range";
end

if norm == true
    Z = normalize(Z, 1, method);
else
end

f = figure("Name", "Image Plot");
f.Units = 'points';
f.Position = [333.6 181.8 442.4 195.2];

imagesc(X, Y, Z, 'AlphaData', alpha)
c = colorbar('northoutside', 'AxisLocation', 'out');
c.Label.String = c_label;
c.Label.FontSize = 12.5;
c.Label.FontName = "Times New Roman";
c.Position = [0.0855 0.7846 0.8982 0.0356];
c.LineWidth = 0.75;

axis xy
xlabel(x_label)
ylabel(y_label)
ax = gca;
ax.FontSize = 12.5;
ax.FontName = "Times New Roman";
ax.Units = "normalized";
ax.LineWidth = 0.95;
colormap(eval(cmap))
ax.OuterPosition = [0.0044 -0.0338 1 0.8303];
ax.InnerPosition = [0.1344 0.1912 0.775 0.5542];
ax.Position = [0.0851 0.1912 0.8982 0.5826];

